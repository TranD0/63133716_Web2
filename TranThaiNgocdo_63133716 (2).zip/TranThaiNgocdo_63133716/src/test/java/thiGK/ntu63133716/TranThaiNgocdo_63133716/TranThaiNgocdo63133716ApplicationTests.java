package thiGK.ntu63133716.TranThaiNgocdo_63133716;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranThaiNgocdo63133716ApplicationTests {

	@Test
	void contextLoads() {
	}

}
