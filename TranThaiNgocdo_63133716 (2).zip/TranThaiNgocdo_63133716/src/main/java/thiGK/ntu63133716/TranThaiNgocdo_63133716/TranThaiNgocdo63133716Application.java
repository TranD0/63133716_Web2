package thiGK.ntu63133716.TranThaiNgocdo_63133716;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranThaiNgocdo63133716Application {

	public static void main(String[] args) {
		SpringApplication.run(TranThaiNgocdo63133716Application.class, args);
	}

}
